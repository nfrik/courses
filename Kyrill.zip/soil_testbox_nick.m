

continuescan = 1;
k=1; %initial number
N=50; %number of sequences
meas=10000;

%fname=dir(fullfile(pwd, '*.txt')); %all files in current dir

fname='CAF_100812_SetA.txt';
% % figure
% plot(time(4:end-4),v2(4:end-4),time(4:end-4),polyval(p,time(4:end-4)))
%for n=1:length(fname(:)) 
fid = fopen(fname);

%N=length(strfind(fileread(fname(n).name),'CrvFitStatus:'));

N=length(strfind(fileread(fname),'CrvFitStatus:'));

a=zeros(N,4);
%a=cell(N,5);

numeric=0;
k=1;
j=1;
C=zeros(50,15);
tline = fgetl(fid);
while ischar(tline)
      if sscanf(tline,'%f',1)>0
          numeric=1;
          %add stuff to buffer
          %disp(tline);
          %C(k,:)=sscanf(tline,'%f %f %*s %*s %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f32',15)';
          st = sscanf(tline,'%f %f %u-%u-%u %u:%u:%u %*s %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f32',24)';
          C(k,1)=st(1);
          C(k,2)=st(2);
          C(k,3)=datenum(st(3),st(4),st(5),st(6),st(7),st(8));
          C(k,4)=st(11);
          C(k,5)=st(12);
          C(k,6)=st(15);
          
          %C(k,:)=sscanf(tline,'%f %f %u-%u-%u %u:%u:%u %*s %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f32',15)';
          %C(k,:)=sscanf(tline,'%d %d %s %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32',15)';
          k=k+1;
      else
          if numeric==1
              
              %do calculations once
              %flush everything to start again
              
              
              indicator=double(C(:,1));
              time=double(C(:,2));
              v2=double(C(:,6));
              datetime=double(C(:,3));
              
              v2filt=v2>0.032;
              
              filt=(time>0)&(indicator==1)&(v2filt);
              v2=v2(filt);
              datetime=datetime(filt);
              time=time(filt);
              

            %p=coeffvalues(fit(time(4:end-4),v2(4:end-4),'poly1'))
            p=double(polyfit(time(30:end-3),v2(30:end-3),1));

            %------------------------
            %compute R2
            yfit=polyval(p,time(30:end-3));
            yresid=v2(30:end-3)-yfit;
            SSresid = sum(yresid.^2);
            SStotal = (length(v2(30:end-3))-1)*var(v2(30:end-3));
            rsq = 1 - SSresid/SStotal;
            %-------------------------
%N2O=(((p(1)*time(end-200)+p(2))-(p(1)*30+p(2)))/(time(end-200)-30))*(7.590/22.4)*(10000/317.8);
            N2O=(((p(1)*300+p(2))-(p(1)*30+p(2)))/270)*(7.590/22.4)*(10000/317.8);
            
 
% N2O=((p(1)*time(end)+p(2))-(p(1)*30+p(2)))/(time(end)-30)*(7.590/22.4)*(10000/317.8);
            % | k | observation | port | observation len | N2O | rsq |
            if ismember(j,meas)
               return
            end
            %throw away bad measurements
            if ~isnan(N2O)
              
              if N2O ~= 0
                a(j,:)=[j, N2O, rsq, datetime(end)];
              end
              disp(['measurement: ' num2str(j) ' ' datestr(datetime(end))]);
              j=j+1;
            end
           
            
            
            %disp(C);
            C=zeros(50,15);
            k=1;
          end
          numeric=0;
          %do dummy stuff
      end      
          tline =fgetl(fid);
end
xlswrite(strrep(fname,'txt','xlsx'),a);
fclose(fid);

%xlswrite(strrep(fname,'txt','xlsx'),a);
%fclose(fid);

% i=1;
% j=2;
% steps=zeros(200,1);
% steps(1)=1;
% tline = fgetl(fid);
% while ischar(tline)
%     if strncmp(tline,'Type',4)
%         steps(j)=i-(j-2); %dirty fix for cycling
%         j=j+1;
%     end
%         
%     if strncmp(tline,'CrvFitStatus',12)
%         steps(j)=i-(j-1); %dirty fix for cycling
%         j=j+1;
%     end
%     
%     i=i+1;
%     %disp(tline)
%     tline=fgetl(fid);
%     %tline = fgetl(fid);
% end
% 
% 
% % i=1;
% % j=1;
% % steps=zeros(200,1);
% % tline = fgetl(fid);
% % while ischar(tline)
% %     if strncmp(tline,'Type',4)
% %         steps(j)=i;
% %         
% %         if j>2
% %            steps(j-1)=i-53;
% %         end
% %         
% %         j=j+2;        
% %     end
% %             
% %     i=i+1;
% %     %disp(tline)
% %     tline=fgetl(fid);
% %     %tline = fgetl(fid);
% % end
% 
% 
% frewind(fid);
% 
% 
% % 
% % for i=steps(1):steps(2)
% %     fgets(fid);
% % end
% % 
% % for i=steps(2):steps(3)
% %     tline=fgets(fid);
% %     disp(tline);
% % end
% % 
% % for i=steps(3):steps(4)
% %     fgets(fid);
% % end
% % 
% % for i=steps(4):steps(5)
% %     tline=fgets(fid);
% %     disp(tline);
% % end
% 
% 
% for j=1:2:9%size(steps)-2
%     %read header lines
%     for i=steps(j):steps(j+1)
%         fgets(fid);
%     end
%     
%     C=zeros(size(steps(j+1):steps(j+2),2),15);
%     k=1;    
%     %read useful data linesclc
%     for i=steps(j+1):steps(j+2)
%         tline=fgetl(fid);
%         %C{j}=sscanf(tline,);
%         C(k,:)=sscanf(tline,'%f %f %*s %*s %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f32',15)';
%         k=k+1;
%     end
%         disp(C);
%     
% end






% while continuescan
% 
% % frewind(fid);
% % obs = textscan(fid, '%s %s',2,'HeaderLines',hdl-25);
% % frewind(fid);
% % obslen = textscan(fid, '%s %s %s',1,'HeaderLines',hdl-22);
% 
% frewind(fid);
% 
% %C = textscan(fid, '%d %d %s %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %d %d %s',...
% C = textscan(fid, '%d %d %s %s %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %f32 %d %d %d %d %s %s %s %s %s %s',...
%     'Delimiter', '\t','HeaderLines',hdl);
% 
% 
% time=double([C{2}]);
% v2=double([C{10}]);%?????? ???? ????? ??????? ?????? ????????? ? ??????? ? 11 ?? 10 ????? ??????
% 
% %p=coeffvalues(fit(time(4:end-4),v2(4:end-4),'poly1'))
% p=double(polyfit(time(30:end),v2(30:end),1));
% 
% %------------------------
% %compute R2
% yfit=polyval(p,time(30:end));
% yresid=v2(30:end)-yfit;
% SSresid = sum(yresid.^2);
% SStotal = (length(v2(30:end))-1)*var(v2(30:end));
% rsq = 1 - SSresid/SStotal;
% %-------------------------
% 
% N2O=((p(1)*time(end)+p(2))-(p(1)*300+p(2)))/(time(end)-300)*(6.808/22.4)*(10000/317.8);
% 
% 
% % | k | observation | port | observation len | N2O | rsq |
% 
% a(k,:)=[k, N2O, rsq];
% 
% 
% hdl=hdl+25+29+length(C{1});%? ??????? ? 31 ?? 29 - ????????? ??????
% k=k+1;
% 
% % figure
% % plot(time(4:end-4),v2(4:end-4),time(4:end-4),polyval(p,time(4:end-4)))
% 
% %exit loop
%  if k>N
%      continuescan = 0;
%  end
% end
%
% 
% xlswrite(strrep(fname,'txt','xls'),a);
% close(fid);

